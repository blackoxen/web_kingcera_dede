<?php
global $em_stars;
$em_stars = array();
$em_stars['1'] = '白羊座';
$em_stars['10'] = '摩羯座';
$em_stars['11'] = '水瓶座';
$em_stars['12'] = '双鱼座';
$em_stars['2'] = '金牛座';
$em_stars['3'] = '双子座';
$em_stars['4'] = '巨蟹座';
$em_stars['5'] = '狮子座';
$em_stars['6'] = '处女座';
$em_stars['7'] = '天枰座';
$em_stars['8'] = '天蝎座';
$em_stars['9'] = '射手座';
?>